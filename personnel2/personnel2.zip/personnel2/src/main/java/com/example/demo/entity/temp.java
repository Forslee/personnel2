package com.example.demo.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Description：
 * DATE:2020/5/14 11:10
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class temp {
    private String userId;
    private Integer point;//积分
}

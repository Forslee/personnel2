package com.example.demo.shiro.realm;

import com.example.demo.entity.Op;
import com.example.demo.entity.Sys;
import com.example.demo.entity.User;
import com.example.demo.service.OpService;
import com.example.demo.service.UserService;
import org.apache.ibatis.annotations.Mapper;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.util.ByteSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;

/**
 * Description：
 * DATE:2020/4/24 16:34
 */
@Service
public class CustomerRealm extends AuthorizingRealm {
    @Autowired
    UserService userService;
    @Autowired
    OpService opService;
    //授权
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {


        Subject subject = SecurityUtils.getSubject();
        User currentUser = (User)subject.getPrincipal();
        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
        //添加角色和设置当前对象的权限
        if(currentUser.getUserType().equals("001")){   //即该用户为系统管理员
             info.addRole("admin");   //对应拥有所有资源权限
            // info.addStringPermission("index:*");       //对应拥有所有增删改查操作
        }else{                                         //即该用户为操作员
            info.addRole("normal");  //没有系统管理权限

        }
        return info;
    }
    //认证
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken) throws AuthenticationException {

        UsernamePasswordToken usernamePasswordToken = (UsernamePasswordToken) authenticationToken;
        User user = userService.findById(usernamePasswordToken.getUsername());
        if(user==null){ return null; }
        if(user.getUserType().equals("002")){ //当前用户为操作员
            Op op = opService.findById(user.getUserId());
            if (op.getPermission().equals("0")) {//当前用户被系统管理员禁用
                throw new AccountException("当前账号已被锁定，请联系系统管理员处理");
            }
        }
        return new SimpleAuthenticationInfo(user,user.getUserPassword(), ByteSource.Util.bytes("SVFX"),this.getName());
    }
}

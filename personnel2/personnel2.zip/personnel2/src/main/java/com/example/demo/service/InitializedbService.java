package com.example.demo.service;

/**
 * Description：
 * DATE:2020/5/15 13:54
 */
public interface InitializedbService {
    int clear_personnelinfo();
    int clear_personneladjustsalary();
    int clear_personnelencourageorpunish();
    int clear_personnelremove();
    int clear_salary();
    int clear_operate();
    int clear_op();
    int clear_job();
    int clear_department();
    int clear_user();
}

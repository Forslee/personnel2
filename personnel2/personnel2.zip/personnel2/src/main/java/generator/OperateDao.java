package generator;

import generator.Operate;

public interface OperateDao {
    int deleteByPrimaryKey(Integer no);

    int insert(Operate record);

    int insertSelective(Operate record);

    Operate selectByPrimaryKey(Integer no);

    int updateByPrimaryKeySelective(Operate record);

    int updateByPrimaryKey(Operate record);
}